#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def set_file_id(data,file_id):
    
    # File ID 설정
    data['File ID']=file_id
    
    # 설정된 File ID Data Frames을 리턴
    return data

